function contact()
{
    window.location.href = "mailto:info@etech-it.com";
}